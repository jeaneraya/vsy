

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <div>
            <?php if(Session::has('info')): ?>
                <div class="alert alert-primary" role="alert">
                    <?php echo e(session('info')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('danger')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('danger')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::has('warning')): ?>
                <div class="alert alert-warning" role="alert">
                    <?php echo e(session('warning')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="col-4">
                <h2 class="main-title">Users</h2>
            </div>
            <div class="col-2"> <a type="button" class="btn btn-primary" href="<?php echo e(route('get_user_create')); ?>">Add
                    Users</a></div>
        </div>

        <div class="container users-page">
            <div class="row stat-cards">

                <div class="col-md-6 col-xl-3">
                    <a href=<?php echo e(route('get_user_index', ['status' => '0'])); ?>>
                        <article class="stat-cards-item">
                            <div class="stat-cards-icon purple">
                                <iconify-icon icon="fa:group"></iconify-icon>
                            </div>
                            <div class="stat-cards-info">
                                <p class="stat-cards-info__num"><?php echo e($allUsers->where('approval_status', '0')->count()); ?></p>
                                <p class="stat-cards-info__title">Pending For Approval</p>
                            </div>
                        </article>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a href=<?php echo e(route('get_user_index', ['status' => '1'])); ?>>
                        <article class="stat-cards-item">
                            <div class="stat-cards-icon purple">
                                <iconify-icon icon="fa:group"></iconify-icon>
                            </div>
                            <div class="stat-cards-info">
                                <p class="stat-cards-info__num"><?php echo e($allUsers->where('approval_status', '1')->count()); ?></p>
                                <p class="stat-cards-info__title">Approved</p>
                            </div>
                        </article>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a href=<?php echo e(route('get_user_index', ['status' => '2'])); ?>>
                        <article class="stat-cards-item">
                            <div class="stat-cards-icon purple">
                                <iconify-icon icon="fa:group"></iconify-icon>
                            </div>
                            <div class="stat-cards-info">
                                <p class="stat-cards-info__num"><?php echo e($allUsers->where('approval_status', '2')->count()); ?></p>
                                <p class="stat-cards-info__title">Rejected</p>
                            </div>
                        </article>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a href=<?php echo e(route('get_user_index', ['status' => '3'])); ?>>
                        <article class="stat-cards-item">
                            <div class="stat-cards-icon purple">
                                <iconify-icon icon="fa:group"></iconify-icon>
                            </div>
                            <div class="stat-cards-info">
                                <p class="stat-cards-info__num"><?php echo e($allUsers->where('approval_status', '3')->count()); ?></p>
                                <p class="stat-cards-info__title">Archived</p>
                            </div>
                        </article>
                    </a>
                </div>

                <div class="col-md-6 col-xl-3">
                    <a href=<?php echo e(route('get_user_index')); ?>>
                        <article class="stat-cards-item">
                            <div class="stat-cards-icon success">
                                <iconify-icon icon="mingcute:group-fill"></iconify-icon>
                            </div>
                            <div class="stat-cards-info">
                                <p class="stat-cards-info__num"><?php echo e($allUsers->count()); ?></p>
                                <p class="stat-cards-info__title">Total Users</p>
                            </div>
                        </article>
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="row">

                    <div class="users-table table-wrapper">
                        <table class="posts-table" id="example">
                            <thead style="padding-left:1em">
                                <tr class="users-table-info">
                                    <th>ID</th>
                                    <th>Role</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <?php
                                $statusBadgeLib = [
                                    0 => '<span class="badge-pending">Pending</span>',
                                    1 => '<span class="badge-success">Approved</span>',
                                    2 => '<span class="badge-trashed">Rejected</span>',
                                    3 => '<span class="badge-active">Archived</span>',
                                ];
                            ?>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e(App\Models\Constants::getRolevalue()[$user->role]); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo $statusBadgeLib[$user->approval_status]; ?>

                                        </td>
                                        <td class="text-center">
                                            <span class="p-relative">
                                                <button class="btn p-0" data-bs-toggle="dropdown" aria-expande="false">
                                                    <iconify-icon icon="gg:more-r"></iconify-icon>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item fs-6"
                                                            href="<?php echo e(route('get_user', ['userId' => $user->id])); ?>">Edit
                                                            Profile</a>
                                                    </li>
                                                    <li>
                                                        <form method="POST"
                                                            action="<?php echo e(route('put_user_archive', ['userId' => $user->id])); ?>">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                                            <button type="submit" class="dropdown-item fs-6">Trash</button>
                                                        </form>
                                                    </li>
                                                    <li>

                                                        <a role="button" data-bs-toggle="modal"
                                                            data-bs-target="#exampleModalCenter"
                                                            data-id='<?php echo e($user->id); ?>' data-role='<?php echo e($user->role); ?>'
                                                            data-name='<?php echo e($user->name); ?>'
                                                            data-mobile='<?php echo e($user->contact); ?>'
                                                            data-address='<?php echo e($user->address); ?>'
                                                            data-approval-status='<?php echo e($user->approval_status); ?>'
                                                            data-cashbond='<?php echo e($user->cashbond); ?>'
                                                            data-code='<?php echo e($user->code); ?>'
                                                            data-ctc-no='<?php echo e($user->ctc_no); ?>'
                                                            class='approval-btn dropdown-item fs-6'>Approval</a>
                                                    </li>
                                                </ul>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Modal -->
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Approval</h5>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form method="POST" action="<?php echo e(route('put_user', ['id' => Auth::id()])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-3 mb-3">
                                        <label for="code" class="form-label">Code:<span
                                                class='span-required'>*<span></label>
                                        <input type="text" class="form-control border border-secondary-subtle"
                                            id="code" name="code" required>
                                    </div>
                                    <div class="col-9 mb-3">
                                        <label for="" class="form-label">Fullname:</label>
                                        <input type="text" class="form-control border border-secondary-subtle"
                                            id="name" name="fullname" required readonly>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label for="" class="form-label">Mobile #:</label>
                                        <input type="text" class="form-control border border-secondary-subtle"
                                            id="mobile" name="mobile" readonly>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label for="" class="form-label">Cashbond:<span
                                                class='span-required'>*<span></label>
                                        <input type="text" class="form-control border border-secondary-subtle"
                                            id="cashbond" name="cashbond" required>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label for="" class="form-label">CTC No<span
                                                class='span-required'>*<span>:</label>
                                        <input type="text" class="form-control border border-secondary-subtle"
                                            id="ctcnum" name="ctcnum" required>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label for="" class="form-label">Address:</label>
                                        <textarea class="form-control" name="address" id="address" cols="30" rows="3" required readonly></textarea>
                                    </div>

                                    <div class="col-12">

                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="approval_status"
                                                id="approved_radio" value="1" checked>
                                            <label class="form-check-label" for="inlineRadio1">Approved</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="approval_status"
                                                id="reject_radio" value="2">
                                            <label class="form-check-label" for="inlineRadio2">Reject</label>
                                        </div>
                                    </div>
                                    <input type="hidden" id="user_id" name="id">
                                    <input type="hidden" id="role" name="role">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>




    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('assets/tools/DataTables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/tools/DataTables/datatables.min.js')); ?>"></script>
        <script>
            $(document).ready(function() {

                // DataTable
                var table = $('#example').DataTable({
                    initComplete: function() {},
                    dom: 'lBfrtip',
                    responsive: true,
                    scrollX: true,
                    lengthChange: false,
                });

                $(".approval-btn").click(function() {

                    // reset modal
                    $("#code").val('');
                    $("#cashbond").val('');
                    $("#ctcnum").val('');
                    $("#name").val('');
                    $("#mobile").val('');
                    $("#address").val('');
                    $("#approved_radio").prop('checked', true);
                    $(".span-required").hide();

                    $("#code").prop('required', false);
                    $("#cashbond").prop('required', false);
                    $("#ctcnum").prop('required', false);

                    $("#code").prop('disabled', true);
                    $("#cashbond").prop('disabled', true);
                    $("#ctcnum").prop('disabled', true);
                    // end reset modal

                    $("#user_id").val($(this).attr('data-id'));
                    $("#name").val($(this).attr('data-name'));
                    $("#mobile").val($(this).attr('data-mobile'));
                    $("#address").val($(this).attr('data-address'));
                    $("#role").val($(this).attr('data-role'));
                    $("#code").val($(this).attr('data-code'));
                    $("#cashbond").val($(this).attr('data-cashbond'));
                    $("#ctcnum").val($(this).attr('data-ctc-no'));

                    // collector
                    if ($(this).attr('data-role') == 3) {
                        $("#code").prop('required', true);
                        $("#ctcnum").prop('required', true);
                        $("#code").prop('required', true);

                        $("#code").prop('disabled', false);
                        $("#cashbond").prop('disabled', false);
                        $("#ctcnum").prop('disabled', false);

                        $(".span-required").show();
                    }
                });
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/admin/users.blade.php ENDPATH**/ ?>