

<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('contents'); ?>
<style>

input:enabled:read-write:-webkit-any(:focus, :hover)::-webkit-calendar-picker-indicator {
   display: block !important;
 }


</style>


    <main class="page-center registration-form">
        <article class="sign-up">
            <img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" class="img" style="width:10%">
            <p class="sign-up__subtitle" style="margin:auto">VSY Collection | Create New Administrator's Account</p>

            <div align="left">
                <?php if(Session::has('info')): ?>
                    <div class="alert alert-primary" role="alert">
                        <?php echo e(session('info')); ?>

                    </div>
                <?php endif; ?>

                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(Session::has('danger')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('danger')); ?>

                    </div>
                <?php endif; ?>
                <?php if(Session::has('warning')): ?>
                    <div class="alert alert-warning" role="alert">
                        <?php echo e(session('warning')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>

            <form class="sign-up-form form" method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <label class="form-label-wrapper col-6">
                        <p class="form-label">Role</p>
                        

                        <select name="role" id="role" type="text"
                            class="form-control <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-input autofocus">
                            <?php
                                $roles = App\Models\Role::all();
                            ?>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>" <?php echo e($role->id == old('role') ? 'selected' : ''); ?>>
                                    <?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>

                    <label class="form-label-wrapper col-6">
                        <p class="form-label">Name</p>
                        <input id="name" type="text"
                            class="form-control input_name <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-input" name="name"
                            value="<?php echo e(old('name')); ?>" placeholder="Enter your name" required autocomplete="name"
                            maxlength="50"
                            autofocus>
                    </label>

                    <label class="form-label-wrapper col-6">
                        <p class="form-label">Birthday</p>
                        <input id="birthday" type="date"
                            class="form-control <?php $__errorArgs = ['birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-input" name="birthday"
                            value="<?php echo e(old('birthday')); ?>" required autocomplete="birthday">
                    </label>


                    <label class="form-label-wrapper col-6">
                        <p class="form-label">Address</p>
                        <input id="address" type="address"
                            class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-input" name="address"  maxlength="100"
                            value="<?php echo e(old('address')); ?>" required autocomplete="address">
                    </label>

                    <label class="form-label-wrapper col-6">
                        <p class="form-label">Contact Number</p>
                        <input id="contact" type="contact"
                            class="form-control input-numbers <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-input" name="contact" maxlength="11" minlength="11"
                            value="<?php echo e(old('contact')); ?>" required autocomplete="contact">
                    </label>

                    <label class="form-label-wrapper col-6">
                        <p class="form-label">Email</p>
                        <input id="email" type="email"
                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-input" name="email"
                            maxlength="50"
                            value="<?php echo e(old('email')); ?>" required autocomplete="email">
                    </label>
                    <label class="form-label-wrapper col-6">
                        <p class="form-label">Password</p>
                        <input id="password" type="password"
                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-input"
                            maxlength="50"
                            placeholder="Enter your password" name="password" required autocomplete="new-password">
                    </label>


                    <label class="form-label-wrapper col-6">
                        <p class="form-label">Confirm Password</p>
                        <input id="password-confirm" type="password" class="form-control form-input"
                            name="password_confirmation" required autocomplete="new-password" maxlength="50">

                    </label>


                </div>
                <button type="submit" class="form-btn primary-default-btn transparent-btn">
                    Create Account
                </button>

            </form>

        </article>
    </main>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $('document').ready(function() {
        // front end input restriction
        $(".input-numbers").keypress(function(event) {
            return /\d/.test(String.fromCharCode(event.keyCode));
        });
        $(".input_name").keypress(function(event) {
            return /^[a-zA-Z.\s]*$/.test(String.fromCharCode(event.keyCode));
        });
    });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/auth/register.blade.php ENDPATH**/ ?>