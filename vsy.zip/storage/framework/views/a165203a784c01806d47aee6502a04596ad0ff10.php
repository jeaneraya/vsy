

<?php $__env->startSection('contents'); ?>
    <style>
        .with-lapse {
            color: red;
        }
    </style>
    <div class="container">
        <h2 class="main-title">Dashboard</h2>
        <div class="row stat-cards">
            <div class="col-md-6 col-xl-3">
                <article class="stat-cards-item">
                    <div class="stat-cards-icon primary">
                        <iconify-icon icon="fluent:money-16-filled"></iconify-icon>
                    </div>
                    <div class="stat-cards-info">
                        <p class="stat-cards-info__num">&#8369;xxx</p>
                        <p class="stat-cards-info__title">Total Collections</p>
                    </div>
                </article>
            </div>
            <div class="col-md-6 col-xl-3">
                <article class="stat-cards-item">
                    <div class="stat-cards-icon warning">
                        <iconify-icon icon="fluent-mdl2:product-list"></iconify-icon>
                    </div>
                    <div class="stat-cards-info">
                        <p class="stat-cards-info__num">xxx</p>
                        <p class="stat-cards-info__title">Total Products</p>
                    </div>
                </article>
            </div>
            <div class="col-md-6 col-xl-3">
                <article class="stat-cards-item">
                    <div class="stat-cards-icon purple">
                        <iconify-icon icon="fa:group"></iconify-icon>
                    </div>
                    <div class="stat-cards-info">
                        <p class="stat-cards-info__num"><?php echo e(count($results['collectors'])); ?></p>
                        <p class="stat-cards-info__title">Total Collectors</p>
                    </div>
                </article>
            </div>
            <div class="col-md-6 col-xl-3">
                <article class="stat-cards-item">
                    <div class="stat-cards-icon success">
                        <iconify-icon icon="mingcute:group-fill"></iconify-icon>
                    </div>
                    <div class="stat-cards-info">
                        <p class="stat-cards-info__num"><?php echo e(count($results['employees'])); ?></p>
                        <p class="stat-cards-info__title">Total Employees</p>
                    </div>
                </article>
            </div>
        </div>


        <div class="row">
            <div class="col-lg-12">
                <div class="users-table table-wrapper">
                    <table class="posts-table">
                        <thead style="padding-left:1em">
                            <tr class="users-table-info">
                                <th>ID</th>
                                <th>Collector's Name</th>
                                <th>Last Payment Date</th>
                                <th>Due Date</th>
                                <th>Lapse Days</th>
                                <th>Balance</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $counter = 0;
                                $today = Carbon\Carbon::now();
                            ?>
                            <?php $__currentLoopData = $results['payments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $counter++;
                                    $lapseDays = Carbon\Carbon::createFromFormat('Y-m-d', $value->payment_date)->diffInDays($today);
                                ?>
                                <tr>
                                    <td><?php echo e($counter); ?></td>
                                    <td><?php echo e($value->name); ?></td>
                                    <td><?php echo e($value->payment_date); ?></td>
                                    <td><?php echo e($results['nextDueDate']); ?></td>
                                    <td class="with-lapse"><?php echo e($lapseDays); ?> days</td>
                                    <td>₱ <?php echo e(number_format((float) $value->balance, 2, '.', '')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/dashboard.blade.php ENDPATH**/ ?>