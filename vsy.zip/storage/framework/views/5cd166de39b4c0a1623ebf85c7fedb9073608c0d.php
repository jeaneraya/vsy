

<?php $__env->startSection('contents'); ?>

    <div class="container">

        <div>
            <?php if(Session::has('info')): ?>
                <div class="alert alert-primary" role="alert">
                    <?php echo e(session('info')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('danger')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('danger')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::has('warning')): ?>
                <div class="alert alert-warning" role="alert">
                    <?php echo e(session('warning')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="col-4">
                <h2 class="main-title">Employees</h2>
            </div>
            <div class="col-2"><a href=<?php echo e(route('create_post_employees')); ?> class="btn btn-primary">Add Employee</a></div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="users-table table-wrapper">
                    <table class="posts-table" id="employees-table">
                        <thead style="padding-left:1em">
                            <tr class="users-table-info">
                                <th>Employee ID</th>
                                <th>Code</th>
                                <th>Employee's Name</th>
                                <th>Address</th>
                                <th>Position</th>
                                <th>Rate</th>
                                <th>Active</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($employee->id); ?></td>
                                    <td><?php echo e($employee->employee_code); ?></td>
                                    <td><?php echo e($employee->fullname); ?></td>
                                    <td><?php echo e($employee->address); ?></td>
                                    <td><?php echo e($employee->position); ?></td>
                                    <td>₱ <?php echo e(number_format((float)$employee->rate_per_day, 2, '.', '')); ?></td>
                                    <td><?php echo e(App\Models\Constants::getHiringStatus()[$employee->hiring_status]); ?></td>
                                    <td class="text-center">
                                        <span class="p-relative">
                                            <button class="btn p-0" data-bs-toggle="dropdown" aria-expande="false">
                                                <iconify-icon icon="gg:more-r"></iconify-icon>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item fs-6"
                                                        href="<?php echo e(route('show_employee', ['id' => $employee->id])); ?>">View/Update</a>
                                                </li>
                                                <li>
                                                    <form method="POST" action="<?php echo e(route('resign_employee')); ?>">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                                        <input hidden name="id" value="<?php echo e($employee->id); ?>">
                                                        <input hidden name="hiring_status" value="<?php echo e($employee->hiring_status == 0 ? '1' : '0'); ?>">
                                                        <button class="dropdown-item fs-6" type="submit">
                                                            <?php echo e($employee->hiring_status == 0 ? 'Mark as Resigned' : 'Mark as Hired'); ?>

                                                        </button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/tools/DataTables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/tools/DataTables/datatables.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {

            // DataTable
            var table = $('#employees-table').DataTable({
                initComplete: function() {},
                dom: 'lBfrtip',
                responsive: true,
                scrollX: true,
                lengthChange: false,
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/employees.blade.php ENDPATH**/ ?>