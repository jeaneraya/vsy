

<?php $__env->startSection('contents'); ?>
    <style>
        input:enabled:read-write:-webkit-any(:focus, :hover)::-webkit-calendar-picker-indicator {
            display: block !important;
        }
    </style>
    <div class="container">
        <h2 class="main-title">Create Users</h2>
        <div>
            <?php if(Session::has('info')): ?>
                <div class="alert alert-primary" role="alert">
                    <?php echo e(session('info')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('danger')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('danger')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::has('warning')): ?>
                <div class="alert alert-warning" role="alert">
                    <?php echo e(session('warning')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>

        <div class="row stat-cards">
            <form class="sign-up-form form" method="POST" action="<?php echo e(route('post_user_create')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-6">
                        <label class="form-label-wrapper">
                            <p class="form-label">Role</p>
                            <select name="role" id="role" type="text"
                                class="form-control <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-input autofocus">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>" <?php echo e($role->id == old('role') ? 'selected' : ''); ?>>
                                        <?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>

                    <div class="col-6">
                        <label class="form-label-wrapper">
                            <p class="form-label">Name</p>
                            <input id="name" type="text"
                                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-input" name="name"
                                value="<?php echo e(old('name')); ?>" placeholder="Enter your name" required autocomplete="name">
                        </label>
                    </div>

                    <div class="col-6">
                        <label class="form-label-wrapper">
                            <p class="form-label">Birthday</p>
                            <input id="birthday" type="date"
                                class="form-control <?php $__errorArgs = ['birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-input" name="birthday"
                                value="<?php echo e(old('birthday')); ?>" required autocomplete="birthday">
                        </label>
                    </div>

                    <div class="col-6">
                        <label class="form-label-wrapper">
                            <p class="form-label">Address</p>
                            <input id="address" type="address"
                                class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-input" name="address"
                                value="<?php echo e(old('address')); ?>" required autocomplete="address">
                        </label>
                    </div>

                    <div class="col-6">
                        <label class="form-label-wrapper">
                            <p class="form-label">Contact Number</p>
                            <input id="contact" type="contact"
                                class="form-control input-numbers <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-input"
                                name="contact" value="<?php echo e(old('contact')); ?>" required autocomplete="contact" maxlength="11"
                                minlength="11">
                        </label>
                    </div>

                    <div class="col-6">
                        <label class="form-label-wrapper">
                            <p class="form-label">Email</p>
                            <input id="email" type="email"
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-input" name="email"
                                value="<?php echo e(old('email')); ?>" required autocomplete="email">
                        </label>
                    </div>

                    <div class="col-6">
                        <label class="form-label-wrapper">
                            <p class="form-label">Password</p>
                            <input id="password" type="password"
                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-input"
                                placeholder="Enter your password" name="password" required autocomplete="new-password">
                        </label>
                    </div>

                    <div class="col-6">
                        <label class="form-label-wrapper">
                            <p class="form-label">Confirm Password</p>
                            <input id="password-confirm" type="password" class="form-control form-input"
                                name="password_confirmation" required autocomplete="new-password">
                        </label>
                    </div>

                    <div class="collector-div row">
                        <h2 class="main-title">Collector Details</h2>

                        <div class="col-6 mb-3">
                            <label for="validationCustom01">Collector Code</label>
                            <input type="text" class="form-control input-numbers form-input" id="code" name="code"
                                placeholder=""  value="<?php echo e(old('code')); ?>">
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        <div class="col-6 mb-3">
                            <label for="validationCustom01">Cashbond</label>
                            <input type="text" class="form-control input-numbers form-input" id="cashbond" name="cashbond"
                                placeholder="" value="<?php echo e(old('cashbond')); ?>" >
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>

                        <div class="col-6 mb-3">
                            <label for="validationCustom01">CTC no.</label>
                            <input type="text" class="form-control input-numbers form-input" id="ctcnum" name="ctcnum"
                                placeholder=""  value="<?php echo e(old('ctcnum')); ?>">
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>

                        <div class="col-6 mb-3">
                            <div class="form-group">
                                <label for="exampleFormControlSelect1">Collector Status</label>
                                <select class="form-control form-input" id="collector_status" name="collector_status" >
                                    <option value="1" <?php echo e(old('ctcnum') == 1 ? 'selected' : ''); ?>>Pending
                                    </option>
                                    <option value="2" <?php echo e(old('ctcnum') == 2 ? 'selected' : ''); ?>>Approved
                                    </option>
                                    <option value="3" <?php echo e(old('ctcnum') == 3 ? 'selected' : ''); ?>>Rejected
                                    </option>
                                    <option value="4" <?php echo e(old('ctcnum') == 4 ? 'selected' : ''); ?>>Archived
                                    </option>
                                </select>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <button type="submit" class="form-btn primary-default-btn transparent-btn">
                    Create Account
                </button>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('document').ready(function() {
            // front end input restriction
            $(".input-numbers").keypress(function(event) {
                return /\d/.test(String.fromCharCode(event.keyCode));
            });
            $(".input_name").keypress(function(event) {
                return /^[a-zA-Z.\s]*$/.test(String.fromCharCode(event.keyCode));
            });

            // initialize
            $('.collector-div').hide();

            // end initialize

            $('#role').change(function(){
                $("#code").prop('required', false);
                $("#ctcnum").prop('required', false);
                $("#code").prop('required', false);

                $("#code").prop('disabled', true);
                $("#cashbond").prop('disabled', true);
                $("#ctcnum").prop('disabled', true);

                $('.collector-div').hide();

                let val = $(this).val();

                if (val == 3) { // collector
                    $('.collector-div').show()

                    $("#code").prop('required', true);
                    $("#ctcnum").prop('required', true);
                    $("#cashbond").prop('required', true);

                    $("#code").prop('disabled', false);
                    $("#cashbond").prop('disabled', false);
                    $("#ctcnum").prop('disabled', false);

                    $(".span-required").show();
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/admin/create_user.blade.php ENDPATH**/ ?>