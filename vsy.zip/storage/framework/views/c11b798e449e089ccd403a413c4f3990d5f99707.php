

<?php $__env->startSection('contents'); ?>
    <div class="container">

        <div>
            <?php if(Session::has('info')): ?>
                <div class="alert alert-primary" role="alert">
                    <?php echo e(session('info')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('danger')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('danger')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::has('warning')): ?>
                <div class="alert alert-warning" role="alert">
                    <?php echo e(session('warning')); ?>

                </div>
            <?php endif; ?>
            <?php
                $show = '';

                if ($errors->any()) {
                    $show = 'show';
                }
            ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="col-4">
                <h2 class="main-title">Payroll</h2>
            </div>
            <div class="col-2"> <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    Add Schedule
                </button></div>
        </div>

        <div class="container users-page">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-12 mb-2">
                        <div class="collapse mt-2" id="collapseExample">
                            <form class="sign-up-form form" method="POST" action="<?php echo e(route('store_payroll_schedule')); ?>">
                                <?php echo csrf_field(); ?>
                                <h2 class="main-title">Add Payroll Schedule</h2>
                                <div class="row">
                                    <div class="col-12">
                                        <label class="form-label-wrapper">
                                            <p class="form-label">Name</p>
                                            <input id="name" type="text"
                                                class="form-control input_name <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-input"
                                                name="name" value="<?php echo e(old('name')); ?>" placeholder="Enter your name"
                                                required autocomplete="name" maxlength="50" autofocus>
                                        </label>
                                    </div>


                                    <div class="col-6">
                                        <label class="form-label-wrapper">
                                            <p class="form-label">Period Start Date</p>
                                            <input id="" type="date"
                                                class="form-control <?php $__errorArgs = ['period_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-input"
                                                value="<?php echo e(old('period_start')); ?>" name="period_start">
                                        </label>
                                    </div>

                                    <div class="col-6">
                                        <label class="form-label-wrapper">
                                            <p class="form-label">Period End Date</p>
                                            <input id="" type="date"
                                                class="form-control <?php $__errorArgs = ['period_end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-input"
                                                name="period_end" value="<?php echo e(old('period_end')); ?>" required>
                                        </label>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label-wrapper">
                                            <p class="form-label">Description</p>
                                            <input id="" type="text"
                                                class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-input"
                                                name="description" value="<?php echo e(old('description')); ?>" required
                                                placeholder="ex. 2023 March 1-15">
                                        </label>
                                    </div>
                                </div>
                                <button type="submit" class="form-btn primary-default-btn transparent-btn">
                                    Submit
                                </button>
                            </form>
                        </div>
                    </div>


                    <div class="users-table table-wrapper">
                        <table class="posts-table" id="example">
                            <thead style="padding-left:1em">
                                <tr class="users-table-info">
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>From (m-d-y)</th>
                                    <th>To (m-d-y)</th>
                                    <th>Total Net</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <?php
                            $scheduleStatus = [
                                0 => '-',
                                1 => 'Active',
                                2 => 'Archived',
                        ];
                            ?>
                            <tbody>
                                <?php $__currentLoopData = $payrollSchedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($result->id); ?></td>
                                        <td><?php echo e($result->name); ?></td>
                                        <td><?php echo e($result->description); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d', $result->from)->format('m-d-Y')); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d', $result->to)->format('m-d-Y')); ?></td>
                                        <td>₱ <?php echo e(number_format((float)$result->total_net, 2, '.', '')); ?> </td>
                                        <td><?php echo e($scheduleStatus[$result->status]); ?></td>
                                        </td>
                                        <td class="text-center">
                                            <span class="p-relative">
                                                <button class="btn p-0" data-bs-toggle="dropdown" aria-expande="false">
                                                    <iconify-icon icon="gg:more-r"></iconify-icon>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item fs-6"
                                                            href="<?php echo e(route('show_payroll_schedule', ['schedule_id' => $result->id])); ?>">View/Update<a>
                                                    </li>
                                                    <li><a class="dropdown-item fs-6"
                                                            href="<?php echo e(route('payroll_computations', ['id' => $result->id])); ?>">Computations<a>
                                                    </li>
                                                    
                                                </ul>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('assets/tools/DataTables/datatables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/tools/DataTables/jquery.dataTables.min.js')); ?>"></script>

        <script>
            $(document).ready(function() {

                // DataTable
                var table = $('#example').DataTable({
                    initComplete: function() {},
                    dom: 'lBfrtip',
                    responsive: true,
                    scrollX: true,
                    lengthChange: false,
                    order: [[0, 'desc']],
                });

                let hasError = <?php echo e(json_encode($errors->any())); ?>


                if (hasError) {
                    $('#collapseExample').collapse(
                        'show'
                    )
                }
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/payroll_schedule.blade.php ENDPATH**/ ?>