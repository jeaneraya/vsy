

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <div>
            <?php if(Session::has('info')): ?>
                <div class="alert alert-primary" role="alert">
                    <?php echo e(session('info')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('danger')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('danger')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::has('warning')): ?>
                <div class="alert alert-warning" role="alert">
                    <?php echo e(session('warning')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="col-4">
                <h2 class="main-title">Notifications</h2>
            </div>
            <div class="col-2"> <a type="button" class="btn btn-primary" href="<?php echo e(route('view_add_reminder')); ?>">Add Reminder</a></div>
            <div class="col-2"> <a type="button" class="btn btn-primary" href="<?php echo e(route('view_reminders_log')); ?>">Automated Logs</a></div>
        </div>

        <?php
            $isActiveBadge = [
                1 => 'Active',
                2 => 'Inactive'
            ];
            $counter = $results->count();
        ?>
    <div class="container users-page">
        <div class="col-lg-12">
            <div class="row">
                <div class="users-table table-wrapper">
                    <table class="posts-table" id="example">
                        <thead style="padding-left:1em">
                            <tr class="users-table-info">
                                <th>ID</th>
                                <th>Type</th>
                                <th>Sent on</th>
                                <th>Message</th>
                                <th>Read</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($counter); ?></td>
                                    <td><?php echo e($result->description); ?></td>
                                    <td><?php echo e($result->sent_datetime); ?></td>
                                    <td><?php echo e($result->message); ?></td>
                                    <td><?php echo e($result->is_read == 1 ? 'YES' : 'NO'); ?></td>
                                    <td><form method="POST" action=<?php echo e(route('update_is_read')); ?>>
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                            <input hidden value="<?php echo e($result->is_read == 1 ? 0 : 1); ?>" name="is_read">
                                            <input hidden value="<?php echo e($result->id); ?>" name="log_id">
                                            <button type="submit" class='btn btn-primary'> <?php echo e($result->is_read == 1 ? 'Unread' : 'Mark as Read'); ?> </button>
                                        </form>
                                       </td>
                                </tr>
                                <?php
                            $counter--;
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/tools/DataTables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/tools/DataTables/jquery.dataTables.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {

            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {},
                dom: 'lBfrtip',
                responsive: true,
                scrollX: true,
                lengthChange: false,
                order: [[0, 'desc']],
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/notifications.blade.php ENDPATH**/ ?>