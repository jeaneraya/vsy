<aside class="sidebar">
    <div class="sidebar-start">
        <div class="sidebar-head">
            <div class="row">
              <div class="col-12 text-center">
                <a href="/" class="logo-wrapper" title="Home">
                  <span class="sr-only">Home</span>
                  <img src="./img/logo/logo.png" class="img m-auto">
                </a>
                <div class="logo-text">VSY System</div>
              </div>
            </div>
        </div>
        <div class="sidebar-body">
            <ul class="sidebar-body-menu">
                <li>
                    <a class="active" href="/"><span class="material-icons-outlined">dashboard</span>Dashboard</a>
                </li>
                <span class="system-menu__title">vsy enterprise</span>
                <ul class="sidebar-body-menu">
                    <li>
                        <a href="appearance.html"><span class="material-icons-outlined">diversity_3</span>Employees</a>
                    </li>
                    <li>
                        <a href="##"><span class="material-icons-outlined">receipt_long</span>Records</a>
                    </li>
                    <li>
                        <a href="appearance.html"><span class="material-icons-outlined">summarize</span>Payroll</a>
                    </li>
                </ul>
                <span class="system-menu__title">vsy collections</span>
                <ul class="sidebar-body-menu">
                    <li>
                        <a href="appearance.html"><span class="material-icons-outlined">groups</span>Collectors</a>
                    </li>
                    <li>
                        <a href="##"><span class="material-icons-outlined">group</span>Suppliers</a>
                    </li>
                    <li>
                        <a href="appearance.html"><span class="material-icons-outlined">inventory_2</span>Stocks</a>
                    </li>
                </ul>
            </ul>
            
        </div>
    </div>
</aside><?php /**PATH C:\laragon\www\vsy_collection\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>