<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin | <?php echo $__env->yieldContent("title"); ?></title>
<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon/favicon.png')); ?>" type="image/x-icon">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

  <!-- Custom styles -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">

      <!-- Bootstrap -->
</head>

<body>
  <div class="layer"></div>
<?php echo $__env->yieldContent("contents"); ?>

<!-- Jquery -->
<script src="<?php echo e(asset('assets/js/jquery-3.7.0.min.js')); ?>"></script>

<!-- Custom scripts -->



<?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\vsy_collection\resources\views/layout/account.blade.php ENDPATH**/ ?>