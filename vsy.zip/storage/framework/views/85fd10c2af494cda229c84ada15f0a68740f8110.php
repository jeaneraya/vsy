

<?php $__env->startSection("title", "Login"); ?>

<?php $__env->startSection("contents"); ?>
<main class="page-center">
  <article class="sign-up">
  <img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" class="img" style="width:35%">
    <p class="sign-up__subtitle">VSY Collection | Signin To Your Account</p>
    <form class="sign-up-form form" action="" method="">
      <label class="form-label-wrapper">
        <p class="form-label">Email</p>
        <input class="form-input" type="email" placeholder="Enter your email" required>
      </label>
      <label class="form-label-wrapper">
        <p class="form-label">Password</p>
        <input class="form-input" type="password" placeholder="Enter your password" required>
      </label>
      <a class="link-info forget-link" href="##">Forgot your password?</a>
      <label class="form-checkbox-wrapper">
        <input class="form-checkbox" type="checkbox" required>
        <span class="form-checkbox-label">Remember me next time</span>
      </label>
      <button class="form-btn primary-default-btn transparent-btn">Sign in</button>
    </form>
  </article>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.account", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/login.blade.php ENDPATH**/ ?>