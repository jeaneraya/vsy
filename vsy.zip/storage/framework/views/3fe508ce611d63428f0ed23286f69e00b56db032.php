

<?php $__env->startSection("contents"); ?>

<div class="container">
        <div class="row">
            <div class="col-4"><h2 class="main-title">Stocks</h2></div>
            <div class="col-2">
              <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addproduct">Add Stocks</button>
            </div>
            <div class="col-3">
              <div class="btn-group">
                <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                  Select Items to Display
                </button>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="<?php echo e(route('products')); ?>">Show Active</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('show-inactive')); ?>">Show In-active</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('show-all')); ?>">Show All</a></li>
                </ul>
              </div>
            </div>
        </div>
        <div class="row container">
          <div class="col-lg-12">
            <div class="users-table table-wrapper">
              <table class="table table-striped posts-table align-middle" id="main-products-table">
                <thead style="padding-left:1em">
                  <tr class="users-table-info">
                    <th>#</th>
                    <th>Product Code</th>
                    <th>Description</th>
                    <th>Unit</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th class="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                <tr>
                <?php
                      $status = [
                          0 => '<span class="badge-trashed">Inactive</span>',
                          1 => '<span class="badge-success">Active</span>',
                      ];
                  ?>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($key + 1); ?></td>
                    <td class="product_code"><?php echo e($product->product_code); ?></td>
                    <td class="description"><?php echo e($product->description); ?></td>
                    <td class="unit"><?php echo e($product->unit); ?></td>
                    <td>&#8369; <?php echo e(number_format($product->price,2)); ?></td>
                    <td><?php echo $status[$product->status]; ?></td>
                    <td class="text-center">
                        <span class="p-relative">
                        <button class="btn p-0" data-bs-toggle="dropdown" aria-expande="false"><iconify-icon icon="gg:more-r"></iconify-icon></button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item fs-6 edit-product-data" data-bs-toggle="modal" data-bs-target="#editProduct" data-id="<?php echo e($product->id); ?>" data-price = "<?php echo e($product->price); ?>" data-status="<?php echo e($product->status); ?>">Edit</a></li>
                            <li><a class="dropdown-item fs-6" href="<?php echo e(route('delete-product', ['id' => $product->id])); ?>" onclick="return confirm('Are you sure you want to delete this product?')">Trash</a></li>
                        </ul>
                        </span>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <script>
                $(document).ready(function() {
                  $('#main-products-table').DataTable();
                });
              </script>
            </div>
          </div>
        </div>
      </div>


      <!-- ADD PRODUCT MODAL -->
      <div class="modal fade" id="addproduct" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="exampleModalLabel">Add Product</h1>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('add-product')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <div class="modal-body">

                  <div class="row">
                    <div class="col-6 mb-3">
                      <label for="code" class="form-label">Product Code:</label>
                      <input type="text" class="form-control border border-secondary-subtle" id="product_code" name="product_code" required>
                    </div>
                    <div class="col-12 mb-3">
                      <label for="" class="form-label">Product Description:</label>
                      <input type="text" class="form-control border border-secondary-subtle" id="description" name="description" required>
                    </div>
                    <div class="col-6 mb-3">
                      <label for="" class="form-label">Unit:</label>
                      <select name="unit" id="unit" class="form-select" required>
                        <option value="" disabled selected></option>
                        <option value="box">Box</option>
                        <option value="pack">Pack</option>
                        <option value="pc">Piece</option>
                      </select>
                    </div>
                    <div class="col-6 mb-3">
                      <label for="" class="form-label">Price:</label>
                      <input type="number" class="form-control border border-secondary-subtle" step="any" min="0" id="price" name="price" required>
                    </div>
                  </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <input type="submit" value="Add Product" class="btn btn-primary">
            </div>
        </form>
          </div>
        </div>
      </div>
      <!-- END OF ADD PRODUCT MODAL -->

      <!-- EDIT PRODUCT MODAL -->
      <div class="modal fade" id="editProduct" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Product</h1>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('edit-product')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <div class="modal-body">

                  <div class="row">
                    <div class="col-6 mb-3">
                      <label for="code" class="form-label">Product Code:</label>
                      <input type="hidden" id="e_product_id" name="e_product_id">
                      <input type="text" class="form-control border border-secondary-subtle" id="e_product_code" name="e_product_code">
                    </div>
                    <div class="col-6 mb-3">
                      <label for="" class="form-label">Unit:</label>
                      <select name="e_unit" id="e_unit" class="form-select">
                        <option value="" disabled selected></option>
                        <option value="box">Box</option>
                        <option value="pack">Pack</option>
                        <option value="pc">Piece</option>
                      </select>
                    </div>
                    <div class="col-12 mb-3">
                      <label for="" class="form-label">Product Description:</label>
                      <input type="text" class="form-control border border-secondary-subtle" id="e_d" name="e_description">
                    </div>
                    <div class="col-6 mb-3">
                      <label for="" class="form-label">Price:</label>
                      <input type="number" class="form-control border border-secondary-subtle" step="any" min="0" id="e_price" name="e_price">
                    </div>
                    <div class="col-6 mb-3">
                      <label for="" class="form-label">Status:</label>
                      <select name="e_status" id="e_status" class="form-select">
                        <option value="1">Active</option>
                        <option value="0">In-active</option>
                      </select>
                    </div>
                  </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <input type="submit" value="Add Product" class="btn btn-primary">
            </div>
        </form>
          </div>
        </div>
      </div>
      <!-- END OF EDIT PRODUCT MODAL -->
      
      <script>
    $(document).on('click','.edit-product-data', function() {
        var _this = $(this).parents('tr');
        var product_id = $(this).data('id');
        var price = $(this).data('price');
        var status = $(this).data('status');

        $('#e_product_id').val(product_id);
        $('#e_product_code').val(_this.find('.product_code').text());
        $('#e_d').val(_this.find('.description').text());
        $('#e_unit').val(_this.find('.unit').text()); 
        $('#e_price').val(price);
        $('#e_status').val(status.toString());
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.design", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/products/index.blade.php ENDPATH**/ ?>