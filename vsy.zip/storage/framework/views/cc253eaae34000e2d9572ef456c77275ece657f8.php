

<?php $__env->startSection('contents'); ?>
    <div class="container">

        <h2 class="main-title">Payroll Computations</h2>

        <div>
            <?php if(Session::has('info')): ?>
                <div class="alert alert-primary" role="alert">
                    <?php echo e(session('info')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('danger')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('danger')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::has('warning')): ?>
                <div class="alert alert-warning" role="alert">
                    <?php echo e(session('warning')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>



        <div class="container users-page">
            <div class="col-lg-12">
                <form class="sign-up-form form">
                    <div class="row">
                        <label class="form-label-wrapper col-12">
                            <p class="form-label">Payroll Schedule</p>
                            <select name="id" id="id" type="text"
                                class="form-control <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-input autofocus">

                                <?php $__currentLoopData = $results['payroll_schedules']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($schedule->id); ?>"
                                        <?php echo e($schedule->id == request()->get('id') ? 'selected' : ''); ?>>
                                        <?php echo e($schedule->name); ?> [<?php echo e($schedule->from); ?> to <?php echo e($schedule->to); ?>] :
                                        <?php echo e($schedule->description); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label class="form-label-wrapper col-12">
                            <div class="">
                                <button type="submit" class="btn btn-primary mb-3" id='see-computations-btn' disabled>See Computations</button>
                            </div>
                        </label>


                        <table class="table mt-2 text-center">
                            <thead>
                                <th>Total Net</th>
                                <th>Claimed</th>
                                <th>Unclaimed</th>
                            </thead>
                            <tbody>

                                <tr>
                                    <td>₱
                                        <?php echo e(number_format((float) $results['withComputations']->sum('computations_net_pay'), 2, '.', '')); ?>

                                    </td>
                                    <td>₱
                                        <?php echo e(number_format((float) $results['withComputations']->where('computations_is_claimed', '1')->sum('computations_net_pay'), 2, '.', '')); ?>

                                    </td>
                                    <td>₱
                                        <?php echo e(number_format((float) $results['withComputations']->where('computations_is_claimed', '0')->sum('computations_net_pay'), 2, '.', '')); ?>

                                    </td>
                                </tr>

                            </tbody>
                        </table>

                    </div>
                </form>

                <form class="sign-up-form form mt-2" method="GET"
                    action="<?php echo e(route('view_add_payroll_computations', [
                        'id' => request()->get('id'),
                    ])); ?>">
                    <div class="row">
                        <label class="form-label-wrapper col-12">
                            <p class="form-label">Employee</p>
                            <select id="employee_dropdown" type="text"
                                class="form-control <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-input autofocus"
                                name="employee_id">
                                <option disabled selected>Select Employee</option>
                                <?php $__currentLoopData = $results['withOutComputations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == '' ? 'selected' : ''); ?>>
                                        <?php echo e($user->fullname); ?> - <?php echo e($user->position); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label class="form-label-wrapper col-12">
                            <div class="">
                                <button disabled id="add-computations-btn" type="submit" class="btn btn-primary mb-3">Add
                                    Computations</button>
                            </div>
                        </label>
                    </div>
                </form>
            </div>


            <div class="users-table table-wrapper mt-2">
                <table class="posts-table" id="example">
                    <thead style="padding-left:1em">
                        <tr class="users-table-info">
                            <th>ID</th>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Gross Pay</th>
                            <th>Deductions</th>
                            <th>Net Pay</th>
                            <th>Claimed</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $results['withComputations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withComputations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($withComputations->employee_id); ?></td>
                            <td><?php echo e($withComputations->employee_code); ?></td>
                            <td><?php echo e($withComputations->employee_full_name); ?></td>
                            <td>₱ <?php echo e(number_format((float) $withComputations->computations_gross, 2, '.', '')); ?></td>
                            <td>₱
                                <?php echo e(number_format((float) $withComputations->computations_total_deductions, 2, '.', '')); ?>

                            </td>
                            <td>₱ <?php echo e(number_format((float) $withComputations->computations_net_pay, 2, '.', '')); ?></td>
                            <td><?php echo e(App\Models\Constants::getPayrollClaimed()[$withComputations->computations_is_claimed]); ?>

                            </td>
                            <td class="text-center">
                                <span class="p-relative">
                                    <button class="btn p-0" data-bs-toggle="dropdown" aria-expande="false">
                                        <iconify-icon icon="gg:more-r"></iconify-icon>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="<?php echo e(route('payroll_computations_employee', ['id' => $withComputations->computations_id, 'employee_id' => $withComputations->employee_id])); ?>"
                                                class="dropdown-item fs-6">View/Update</a>
                                        </li>
                                        <li>
                                            <form method="POST"
                                                action="<?php echo e(route('put_payroll_computation_claim', ['id' => $withComputations->computations_id])); ?>">
                                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                                <input hidden name='is_claimed'
                                                    value="<?php echo e($withComputations->computations_is_claimed == 1 ? 0 : 1); ?>">
                                                <input hidden name='schedule_id' value="<?php echo e(request()->get('id')); ?>">
                                                <button type="submit" class="dropdown-item fs-6">
                                                    <?php echo e($withComputations->computations_is_claimed == 1 ? 'Unclaim' : 'Mark as Claimed'); ?>

                                                </button>
                                            </form>


                                        </li>
                                    </ul>
                                </span>
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/tools/DataTables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/tools/DataTables/jquery.dataTables.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {},
                dom: 'lBfrtip',
                responsive: true,
                scrollX: true,
                lengthChange: false,
            });

            $('#employee_dropdown').change(function() {
                let val = $(this).val();
                $("#add-computations-btn").prop('disabled', false);
            })

            $('#id').change(function() {
                let val = $(this).val();
                $("#see-computations-btn").prop('disabled', false);
            })

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/payroll_computation_index.blade.php ENDPATH**/ ?>