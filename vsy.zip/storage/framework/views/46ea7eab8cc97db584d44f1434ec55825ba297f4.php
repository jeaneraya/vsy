

<?php $__env->startSection("title","Register"); ?>

<?php $__env->startSection("contents"); ?>
<main class="page-center">
<article class="sign-up">
    <img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" class="img" style="width:20%">
    <p class="sign-up__subtitle">VSY Collection | Create New Administrator's Account</p>
    <form class="sign-up-form form" action="" method="">
      <label class="form-label-wrapper">
        <p class="form-label">Name</p>
        <input class="form-input" type="text" placeholder="Enter your name" required>
      </label>
      <label class="form-label-wrapper">
        <p class="form-label">Username</p>
        <input class="form-input" type="text" placeholder="Enter your email" required>
      </label>
      <label class="form-label-wrapper">
        <p class="form-label">Password</p>
        <input class="form-input" type="password" placeholder="Enter your password" required>
      </label>
      <button class="form-btn primary-default-btn transparent-btn">Create Account</button>
    </form>
  </article>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.account", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsy_collection\resources\views/register.blade.php ENDPATH**/ ?>