<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>VSY Collection</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon/favicon.png')); ?>" type="image/x-icon">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">

    <!-- Material Icon -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">

    <!-- Custom styles -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    <!-- Iconify -->
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>

    <!-- Jquery -->
    <script src="<?php echo e(asset('assets/js/jquery-3.7.0.min.js')); ?>"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js"></script>


</head>
<body onload="window.print();">

<div class="container">
    <div class="row pb-2" style="border-bottom: 1px solid #cbcbcb">
    <h4 style="border-bottom:1px solid #cbcbcb" class="text-center py-2">Credit Computation Report</h4>
        <div class="col-6">
            <?php $__currentLoopData = $users_infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $am_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mt-1">
                <div class="col-3">Code:</div>
                <div class="col-9"><?php echo e($am_info->code); ?></div>
            </div>
            <div class="row">
                <div class="col-3">Name:</div>
                <div class="col-9"><?php echo e($am_info->name); ?></div>
            </div>
            <div class="row">
                <div class="col-3">Contact #:</div>
                <div class="col-9"><?php echo e($am_info->contact); ?></div>
            </div>
        </div>
        <div class="col-6">
            <div class="row mt-1">
                <div class="col-3">Address:</div>
                <div class="col-9"><?php echo e($am_info->address); ?></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-5">Period Covered:</div>
                <div class="col-7"> <?php echo e(date('m-d-Y', strtotime($transaction->period_from))); ?> to <?php echo e(date('m-d-Y', strtotime($transaction->period_to))); ?></div>
            </div>
            <div class="row">
                <div class="col-5">Batch #:</div>
                <div class="col-7"> <?php echo e($transaction->num); ?></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="row">
        <table class="table table-striped" style="font-size: 12px;">
            <thead style="padding-left:1em">
              <tr>
                <th colspan="7">Withdrawals Summary</th>
              </tr>
              <tr class="users-table-info">
                <th>Delivered</th>
                <th>Returned</th>
                <th>Sold</th>
                <th>Unit</th>
                <th>Description</th>
                <th>Price</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
                <?php
                $total_out = 0;
                $total_return = 0;
                $total_qty = 0;
                $total_sold = 0;
                $grand_total = 0;
                $total_amount_sold = 0;
                $sold_qty = 0;
                ?>
              <?php $__currentLoopData = $batch_withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $total_out += $bw->qty;
                $total_return += $bw->return_qty;
                $total_qty += $bw->qty - $bw->return_qty;
                $sold_qty = $bw->qty - $bw->return_qty;
                $total_sold = $sold_qty * $bw->price;
                $total_amount_sold += $total_sold;
              ?>
                  <tr>
                      <td><?php echo e($bw->qty); ?></td>
                      <td><?php echo e($bw->return_qty); ?></td>
                      <td><?php echo e($bw->qty - $bw->return_qty); ?></td>
                      <td><?php echo e($bw->unit); ?></td>
                      <td><?php echo e($bw->description); ?></td>
                      <td>&#8369; <?php echo e(number_format($bw->price,2)); ?></td>
                      <td>&#8369; <?php echo e(number_format($total_sold,2)); ?></td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
                <td><strong><?php echo e($total_out); ?></strong></td>
                <td><strong><?php echo e($total_return); ?></strong></td>
                <td><strong><?php echo e($total_qty); ?></strong></td>
                <td colspan="2"></td>
                <td><strong>Total:</strong></td>
                <td><strong>&#8369; <?php echo e(number_format($total_amount_sold,2)); ?></strong></td>
            </tr>
          </tfoot>
          </table>
    </div>
    <div class="row">
        <table class="table table-striped" style="font-size: 12px;">
            <thead style="padding-left:1em">
              <tr>
                <th colspan="2">Expenses Summary</th>
              </tr>
              <tr class="users-table-info">
                <th>Description</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
                <?php
                $total_expenses = 0;
                $expenses_with_interest = 0;
                ?>
              <?php $__currentLoopData = $expenses_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $et): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $total_expenses += $et->amount;
              ?>
                  <tr>
                      <td><?php echo e($et->description); ?></td>
                      <td>&#8369; <?php echo e(number_format($et->amount,2)); ?></td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
                <td></td>
                <td><strong>&#8369; <?php echo e(number_format($total_expenses,2)); ?></strong></td>
            </tr>
          </tfoot>
          </table>
    </div>
    <div class="row p-0">
        <table>
            <tbody>
                <tr>
                    <td style="text-align:right; padding-right:5em"><strong>Add: 5.8% for 5 mos. until the account is fully paid</strong></td>
                    <td>&#8369; <?php echo e($total_expenses*(29/100)); ?></td>
                </tr>
                <tr>
                    <td style="text-align:right; padding-right:5em"><strong>Total Expenses:</strong></td>
                    <td>&#8369; <?php echo e($total_expenses*(29/100) + $total_expenses); ?></td>
                </tr>
                <tr>
                    <td style="text-align:right; padding-right:5em"><strong>Grand Total:</strong></td>
                    <td>&#8369; <?php echo e($total_expenses*(29/100) + $total_expenses + $total_sold); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="row mt-3">
        <div class="col-12">
            <p>Prepared by: ___________________________ Date:</p>
            <p align="right" class="mt-4">Received by: ___________________________ Date:</p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>

</body>

</html><?php /**PATH C:\laragon\www\vsy_collection\resources\views/collectors/printables/credit_computation.blade.php ENDPATH**/ ?>