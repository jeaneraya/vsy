1. composer update
2. php artisan migrate:refresh && php artisan db:seed
3. php artisan serve
