<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PayrollConstantsController extends Controller
{
    //
}
