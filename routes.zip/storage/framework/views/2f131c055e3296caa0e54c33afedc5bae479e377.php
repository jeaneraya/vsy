<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>VSY Collection</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon/favicon.png')); ?>" type="image/x-icon">

    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">

    <!-- Material Icon -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">

    <!-- Custom styles -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    <!-- Iconify -->
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>

    <!-- Jquery -->
    <script src="<?php echo e(asset('assets/js/jquery-3.7.0.min.js')); ?>"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js"></script>

    <!-- JS for DataTables -->
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>

</head>

<body>
    <div class="layer"></div>
    <!-- ! Body -->
    <a class="skip-link sr-only" href="#skip-target">Skip to content</a>
    <div class="page-flex">
        <!-- ! Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-start">
                <div class="sidebar-head">
                    <div class="row">
                        <div class="col-12 text-center">
                            <a href="/" class="logo-wrapper" title="Home">
                                <span class="sr-only">Home</span>
                                <img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" class="img m-auto">
                            </a>
                            <div class="logo-text">VSY System</div>
                        </div>
                    </div>
                </div>
                <div class="sidebar-body">
                    <ul class="sidebar-body-menu">
                        <li>
                          <a class="<?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">
                            <span class="material-icons-outlined">dashboard</span>
                            Dashboard
                        </a>
                        </li>
                        <span class="system-menu__title">vsy enterprise</span>
                        <ul class="sidebar-body-menu">
                            <?php if(Auth::user()->role == 1): ?>
                                <li>
                                    <?php
                                    $forApprovalCount = count(\App\Models\User::where([
                                        ['approval_status', '=', '0']
                                        ])->get());


                                    $approvalBadge = $forApprovalCount > 0
                                     ? "<span class='badge badge-danger'>$forApprovalCount</span>"
                                     : ''
                                 ?>


                                    <a class="<?php echo e(request()->routeIs('get_user_index') ? 'active' : ''); ?>" href="<?php echo e(route('get_user_index')); ?>"><span class="material-icons-outlined">groups</span>Users <?php echo $approvalBadge; ?>


                                    </a>
                                </li>
                            <?php endif; ?>
                            <li>
                                <a class="<?php echo e(request()->routeIs('employees') ? 'active' : ''); ?>" href="<?php echo e(route('employees')); ?>"><span class="material-icons-outlined">diversity_3</span>Employees</a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->routeIs('payroll_schedule') ? 'active' : ''); ?>" href="<?php echo e(route('payroll_schedule')); ?>"><span class="material-icons-outlined">diversity_3</span>Payroll</a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->routeIs('reminders') ? 'active' : ''); ?>" href="<?php echo e(route('reminders')); ?>"><span class="material-icons-outlined">diversity_3</span>Reminders</a>
                            </li>
                        </ul>
                        <span class="system-menu__title">vsy collections</span>
                        <ul class="sidebar-body-menu">
                            <li>
                                <a class="<?php echo e(request()->routeIs('collectors') ? 'active' : ''); ?>" href="<?php echo e(route('collectors')); ?>"><span class="material-icons-outlined">groups</span>Collectors</a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->routeIs('suppliers') ? 'active' : ''); ?>" href="<?php echo e(route('suppliers')); ?>"><span class="material-icons-outlined">group</span>Suppliers</a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->routeIs('products') ? 'active' : ''); ?>" href="<?php echo e(route('products')); ?>"><span class="material-icons-outlined">inventory_2</span>Products</a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->routeIs('ap_list') ? 'active' : ''); ?>" href="<?php echo e(route('ap_list')); ?>"><span class="material-icons-outlined">list_alt</span>AP List</a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->routeIs('expenses') ? 'active' : ''); ?>" href="<?php echo e(route('expenses')); ?>"><span class="material-icons-outlined">playlist_add_check</span>Expenses</a>
                            </li>
                        </ul>
                    </ul>

                </div>
            </div>
        </aside>
        <div class="main-wrapper">
            <!-- ! Main nav -->
            <nav class="main-nav--bg">
                <div class="container main-nav">
                    <div class="main-nav-start">
                    </div>
                    <div class="main-nav-end">
                        <button class="sidebar-toggle transparent-btn" title="Menu" type="button">
                            <span class="sr-only">Toggle menu</span>
                            <span class="icon menu-toggle--gray" aria-hidden="true"></span>
                        </button>
                        <div class="notification-wrapper dropstart">
                            <?php
                            $notifications = App\Models\RemindersLogger::where([
                                    ['sent_via', '=', '2'], // notifications
                                    ['sent_to', '=', Auth::user()->id],
                                    ['is_read', '=', 0]
                                ])->orderBy('id', 'desc')
                                ->get();
                            ?>
                            <button class="btn p-0 p-relative" data-bs-toggle="dropdown" aria-expande="false">
                                <span class="">
                                    <iconify-icon icon="mi:notification" class="font-size:1.5em"></iconify-icon>
                                </span>
                                <span class="icon notification <?php echo e($notifications->count() > 0 ? 'active' : ''); ?>" aria-hidden="true"></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg-start">
                                <li><a class="dropdown-item fs-6" href="<?php echo e(route('notifications_index')); ?>"><?php echo e($notifications->count() . " new notifications."); ?></a></li>
                            </ul>
                        </div>
                        <div class="nav-user-wrapper dropstart">
                            <button href="##" class="btn" data-bs-toggle="dropdown" aria-expande="false">
                                <span class="sr-only">My profile</span>
                                <span class="nav-user-img">
                                    <iconify-icon icon="ph:user-fill"></iconify-icon>
                                </span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg-start">
                                <li class="dropdown-item"><a href="##">
                                        <i data-feather="user" aria-hidden="true"></i>
                                        <span>Profile</span>
                                    </a></li>
                                <li class="dropdown-item"><a href="##">
                                        <i data-feather="settings" aria-hidden="true"></i>
                                        <span>Account settings</span>
                                    </a></li>
                                

                                <li class="dropdown-item">
                                    <a data-feather="log-out" aria-hidden="true" class="dropdown-item"
                                        href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">
                                        <span> <?php echo e(__('Logout')); ?></span>
                                    </a>
                                </li>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>


                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- ! Main -->
            <main class="main users chart-page" id="skip-target">
                <?php echo $__env->yieldContent('contents'); ?>
            </main>
            <!-- ! Footer -->
        </div>

    </div>


    <!-- Custom scripts -->
    <!-- <script src="<?php echo e(asset('assets/plugins/script.js')); ?>"></script> -->
    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>

    <!-- Custom scripts -->
    <!--  -->

    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\vsy_collection\resources\views/layout/design.blade.php ENDPATH**/ ?>