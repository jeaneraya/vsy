<!DOCTYPE  html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ms" lang="ms"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"/><title>file_1690803930115</title><meta name="author" content="VSYE"/>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
<style type="text/css"> * {margin:0; padding:0; text-indent:0; font-family:"Times New Roman", serif;}
 .s1 { color: black; font-family:"Times New Roman", serif; font-style: normal; font-weight: normal; text-decoration: underline; font-size: 20pt; }
 .s2 { color: black; font-family:"Times New Roman", serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 20pt; }
 .s3 { color: black; font-family:"Times New Roman", serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 12pt; }
 .p, p { color: black; font-family:"Times New Roman", serif; font-style: italic; font-weight: normal; text-decoration: none; font-size: 12pt; margin:0pt; }
 .h2, h2 { color: black; font-family:Cambria, serif; font-style: italic; font-weight: bold; font-size: 12pt; }
 .s4 { color: black; font-family:Cambria, serif; font-style: italic; font-weight: bold; text-decoration: none; font-size: 12pt; }
 .s5 { color: black; font-family:"Times New Roman", serif; font-style: italic; font-weight: bold; text-decoration: none; font-size: 12pt; }
 .s6 { color: black; font-family:"Times New Roman", serif; font-style: normal; font-weight: normal; text-decoration: underline; font-size: 12pt; }
 .s7 { color: black; font-family:"Times New Roman", serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 12pt; }
 .s8 { color: black; font-family:"Times New Roman", serif; font-style: italic; font-weight: bold; text-decoration: underline; font-size: 12pt; }
 .s10 { color: black; font-family:Cambria, serif; font-style: normal; font-weight: normal; text-decoration: underline; font-size: 12pt; }
 .s11 { color: black; font-family:Cambria, serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 12pt; }
 h1 { color: black; font-family:"Times New Roman", serif; font-style: normal; font-weight: bold; text-decoration: underline; font-size: 13pt; }
 li {display: block; }
 #l1 {padding-left: 0pt;counter-reset: c1 1; }
 #l1> li>*:first-child:before {counter-increment: c1; content: counter(c1, decimal)". "; color: black; font-family:"Times New Roman", serif; font-style: italic; font-weight: normal; text-decoration: none; font-size: 12pt; }
 #l1> li:first-child>*:first-child:before {counter-increment: c1 0;  }
 #l2 {padding-left: 0pt;counter-reset: c2 1; }
 #l2> li>*:first-child:before {counter-increment: c2; content: counter(c2, upper-latin)". "; color: black; font-family:"Times New Roman", serif; font-style: italic; font-weight: normal; text-decoration: none; font-size: 12pt; }
 #l2> li:first-child>*:first-child:before {counter-increment: c2 0;  }
 li {display: block; }
 #l3 {padding-left: 0pt;counter-reset: d1 11; }
 #l3> li>*:first-child:before {counter-increment: d1; content: counter(d1, upper-latin)". "; color: black; font-family:"Times New Roman", serif; font-style: italic; font-weight: normal; text-decoration: none; font-size: 12pt; }
 #l3> li:first-child>*:first-child:before {counter-increment: d1 0;  }
</style></head><body onload="window.print();">
    @foreach($collector_details as $cd)
    <p class="s1" style="padding-top: 3pt;padding-left: 4pt;text-indent: 0pt;text-align: center;">K<span class="s2"> </span>A<span class="s2"> </span>S<span class="s2"> </span>U<span class="s2"> </span>N<span class="s2"> </span>D<span class="s2"> </span>U<span class="s2"> </span>A<span class="s2"> </span>N</p><p style="text-indent: 0pt;text-align: left;"><br/></p><p class="s3" style="padding-top: 4pt;padding-left: 5pt;text-indent: 0pt;text-align: left; margin-top: 2em;">DAPAT ALAMIN NG SINUMAN NA:</p><p style="text-indent: 0pt;text-align: left;"><br/></p><h2 style="padding-left: 5pt;text-indent: 36pt;text-align: justify;"><span class="p">AKO, Si </span><span style="text-decoration: underline;">VIRGILIO  S.  YUMUL</span><span class="s4"> </span><span class="p">nasa wastong gulang </span>may  asawa<span class="s4"> </span><span class="p">at kasalukuyang naninirahan sa </span><span style="text-decoration: underline;">SALCEDO VILLAGE, SUDAPIN, KIDAPAWAN CITY</span><span class="p">, at kilala sa Kasunduang ito bilang</span></h2><p class="s5" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">UNANG PANIG<span class="p">; at</span></p><p style="text-indent: 0pt;text-align: left;"><br/></p><p style="padding-left: 5pt;text-indent: 30pt;text-align: left;">Ako si <u>&nbsp;&nbsp; </u><span class="h2" style="text-decoration: underline;">{{ $cd->name }}  </span>nasa wastong <span class="s7">gulang,may </span>kinakasama na si <u>&nbsp; </u><span class="h2" style="text-decoration: underline;">{{ $cd->spouse }} </span><span class="s4"> </span>at kasalukuyang naninirahan sa <u>&nbsp;</u><span class="h2" style="text-decoration: underline;">{{ $cd->address }} </span>at kilala sa kasunduang ito bilang <b>IKALAWANG PANIG</b>; ay nagkasundo sa mga sumusunod:</p><p style="text-indent: 0pt;text-align: left;"><br/></p><ol id="l1"><li data-list-text="1."><p style="padding-left: 5pt;text-indent: 0pt;text-align: left;">Na ang <b>UNANG PANIG </b>ay nakarehistro bilang isang lehitimong kalakal na nagbebenta ng home decors, religious article and household items.</p><p style="text-indent: 0pt;text-align: left;"><br/></p></li><li data-list-text="2."><p style="padding-left: 5pt;text-indent: 0pt;text-align: left;">Na ang <b>IKALAWANG PANIG </b>ay nag-apply bilang <b>AHENTE/KOLEKTOR </b>ng UNANG PANIG at tinanggap ito ng huli ayon sa mga sumusunod na kundisyon.</p><p style="text-indent: 0pt;text-align: left;"><br/></p><ol id="l2"><li data-list-text="A."><p style="padding-left: 23pt;text-indent: 0pt;text-align: justify;">Na ang IKALAWANG PANIG ay pinapayagang kumuha ng paninda sa UNANG PANIG at ito ay base sa presyong itatalaga ng UNANG PANIG.</p><p style="text-indent: 0pt;text-align: left;"><br/></p></li><li data-list-text="B."><p style="padding-left: 23pt;text-indent: 0pt;text-align: justify;">Na ang mga panindang kukunin sa UNANG PANIG ng IKALAWANG PANIG ay ibebenta ng huli sa mga tao at ang IKALAWANG PANIG ang bahalang maningil sa mga tao.</p></li></ol></li></ol><p style="text-indent: 0pt;text-align: left;"><br/></p><ol id="l3"><li data-list-text="K."><p style="padding-left: 23pt;text-indent: 0pt;text-align: justify;">Na bilang AHENTE/KOLEKTOR, ang IKALAWANG PANIG ay may obligasyon sa UNANG PANIG na ipasa o i-remit sa huli lahat ng kanyang koleksyon;</p><p style="text-indent: 0pt;text-align: left;"><br/></p><p style="padding-left: 23pt;text-indent: 0pt;text-align: justify;">D. Na bago ibenta ang mga panindang kinuha ng IKALAWANG PANIG sa UNANG PANIG, ang nasabing IKALAWANG PANIG ay maaring kumuha sa UNANG PANIG ng “vale” o “Cash advance” bilang paunang gastos niya sa kanyang pagtitinda.</p><p style="text-indent: 0pt;text-align: left;"><br/></p><p style="padding-left: 23pt;text-indent: 0pt;text-align: justify;">E. Na ang nasabing <b>“Vale” o “Cash advance” </b>ay pananagutan ng IKALAWANG PANIG at dapat niyang maibalik sa UNANG PANIG sa oras na magpasa ng kanyang koleksyon sapagkat ito ay itinuturing ng UNANG PANIG na dagdag na puhunan sa mga panindang iyon;</p><p style="text-indent: 0pt;text-align: left;"><br/></p><p style="padding-left: 23pt;text-indent: 0pt;text-align: justify;">G. Na ang aktwal na puhunan ng paninda at ang <b>“Vale” o “Cash advance” </b>ng IKALAWANG PANIG ang bumubuo sa kapital ng nasabing mga paninda.</p><p style="text-indent: 0pt;text-align: left;"><br/></p><p class="s5" style="padding-top: 11pt;padding-left: 23pt;text-indent: 0pt;text-align: justify;"><span class="p">H. At ito ay babayaran ng IKALAWANG PANIG sa UNANG PANIG sa mga kalakal na nakuha nito sa huli. At ito ay babayaran sa loob </span>5- <u>LIMANG BUWAN</u> <span class="p">matapos na maibenta.</span></p><p style="text-indent: 0pt;text-align: left;"><br/></p><p class="s8" style="padding-left: 23pt;text-indent: 0pt;text-align: justify;"><span class="p">I. Na matapos ibenta ng IKALAWANG PANIG ang mga kalakal ng UNANG PANIG ito ay babayaran sa unang singil tuwing </span>IKA LABING LIMA AT TATLOMPUNG<span class="s5"> </span>ARAW (15-30) NG BUWAN<span class="s5"> </span><span class="p">ayon sa napagkasunduang araw o petsa.</span></p></li><li data-list-text="L."><p style="padding-top: 3pt;padding-left: 23pt;text-indent: 0pt;text-align: justify;">Na ang pagbebenta ng mga paninda ay gagawin ng IKALAWANG PANIG sa loob ng <u>(40) DAYS / APATNAPUNG ARAW</u> mula ng pagtanggap niya ng paninda mula sa UNANG PANIG.</p><p style="text-indent: 0pt;text-align: left;"><br/></p></li><li data-list-text="M."><p style="padding-left: 23pt;text-indent: 0pt;text-align: justify;">Na ang lahat ng hindi naibenta ay isasauli ng IKALAWANG PANIG sa loob (10) sampung araw matapos ang taning ng pagbebenta.</p><p style="text-indent: 0pt;text-align: left;"><br/></p></li><li data-list-text="N."><p style="padding-left: 23pt;text-indent: 0pt;text-align: justify;">Pag hindi naisauli ng IKALAWANG PANIG ang mga produkto sa araw na itinakda ito ay itinuturing (sold) naibenta na.</p><p style="text-indent: 0pt;text-align: left;"><br/></p></li><li data-list-text="O."><p style="padding-left: 23pt;text-indent: 0pt;text-align: justify;">Na anumang paglabag ng IKALAWANG PANIG sa kasunduang ito ay magiging daan upang magsampa ang UNANG PANIG laban sa IKALAWANG PANIG ng demanda para sa kasong <b>“ESTAFA” </b>sa tamang hukuman o korte.</p></li></ol><p style="text-indent: 0pt;text-align: left;"><br/></p><p class="s7" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">GINAWA naming ngayong ika - <strong><u id="ika-day">&nbsp;&nbsp; </u></strong>&nbsp;&nbsp;ng&nbsp;&nbsp; <strong><u id="ng-month"></u></strong><span>,&nbsp;</span><b id="year"></b>  dito sa <u>Salcedo Village,</u> <u>Sudapin, Kidapawan City.</u></p><p style="text-indent: 0pt;text-align: left;"><br/></p>
    <div class="row">
        <div class="col-6">
            <p class="m-0 s3" style="padding-left: 4pt;text-indent: 0pt;">UNANG PANIG</p>
            <p class="s10" style="padding-top: 4pt;padding-left: 4pt;text-indent: 0pt; text-decoration: underline;">
                VIRGILIO S. YUMUL
            </p>
            <p class="m-0">LIC NO. L03-88-013313</p>
        </div>
        <div class="col-6">
            <p class="m-0 s3" style="padding-left: 4pt;text-indent: 0pt;">IKALAWANG PANIG</p>
            <p class="s10" style="padding-top: 4pt;padding-left: 4pt;text-indent: 0pt; text-decoration: underline; text-transform:uppercase">
                {{$cd->name}}
            </p>
            <p class="m-0">{{$cd->id_num}}</p>
        </div>
        <div class="row d-flex justify-content-end mt-3">
            <div class="col-6">
                <p class="m-0 s3" style="padding-left: 4pt;text-indent: 0pt;">IKINAKASAMA NA SI</p>
                <p class="s10" style="padding-top: 4pt;padding-left: 4pt;text-indent: 0pt; text-decoration: underline;text-transform:uppercase">
                    {{$cd->spouse}}
                </p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row mt-5">
            <h1 class="my-3" style="padding-top: 4pt;text-indent: 0pt;text-align: center;">ACKNOWLEDGEMENT</h1>
            <div class="col-4">Republic of the Philippines</div>
            <div class="col-8">)</div>
            <div class="col-4">Kidapawan City, North Cotabato</div>
            <div class="col-8">)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; S.S.</div>
            <div class="col-12 mt-3">
                <p>BEFORE ME, On this <strong><u id="day"></u></strong><span> of </span><strong><u id="month"></u></strong><span>,  </span><strong><u id="current_year"></u></strong> at ______________________________, ___________________, personally appeared the following:</p>
                <p class="mt-4">Known to me the same persons who executed the foregoing instrument and they acknowledged to me that the same is their free act and deed.</p>
                <p class="mt-4">
                    <strong>WITNESS MY HAND AND SEAL</strong> on the date and place above-written.
                </p>
            </div>
        </div>
    </div>
    
@endforeach
<script>

            const currentDate = new Date();
            const dayOfMonth = currentDate.getDate();
            const daySuffix = getDaySuffix(dayOfMonth);
            const month = currentDate.toLocaleString('default', { month: 'long' });
            const year = currentDate.getFullYear();

        function getDaySuffix(day) {
            if (day === 1 || day === 21 || day === 31) {
                return "st";
            } else if (day === 2 || day === 22) {
                return "nd";
            } else if (day === 3 || day === 23) {
                return "rd";
            } else {
                return "th";
            }
        }

        const withSuffix = dayOfMonth.toString() + daySuffix;
        
        document.getElementById('day').innerText = withSuffix;
        document.getElementById('month').innerText = month;
        document.getElementById('current_year').innerText = year;
        document.getElementById('ika-day').innerText = dayOfMonth;
        document.getElementById('ng-month').innerText = month;
        document.getElementById('year').innerText = year;
    </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>
</body>
</html>
